package com.company.raceGame.raceGame;

/**
 * Class GameCreating that creates game (sets number of players, cars and track)
 * @author Rodion Ibragimov
 * @version 2.228
 */

public class GameCreating {
    /**
     * Int array of numbers of players
     */
    private final int[] PLAYERS = {1, 2, 3};

    /**
     * String array of cars
     */
    private final String[] CARS = {"Jeep", "Racing car", "Supercar"};

    /**
     * String array of tracks
     */
    private final String[] TRACKS = {"Offroad", "Curcuit", "City"};


    /**
     * Setter number of Players
     */
    public void setPlayers() {

    }

    /**
     * Setter the type of car
     */
    public void setCar() {

    }

    /**
     * Setter the type of track
     */
    public void setTrack() {

    }
}
